﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetProject.Models;
using VishvajeetProject.Respository.Contract;

namespace VishvajeetProject.Controllers
{
    /*[Authorize]*/
    public class CategoryController : Controller
    {
        private ICategory categoryService;
        private readonly IHostingEnvironment Environment;
        public CategoryController(ICategory category,IHostingEnvironment environment) 
        {
            categoryService = category;
            Environment = environment;
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Category category)
        {
            /*var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "products", files[0].FileName);
                dbpath = "products/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            product.Image = dbpath;*/
            var p = categoryService.CreateCategory(category);
            return RedirectToAction("Create", "Category");
        }

        public IActionResult Delete(int id)
        {
            var d = categoryService.DeleteCategory(id);
            return RedirectToAction("Index", "Product");
        }
        public IActionResult Update(string name)
        {
            var u = categoryService.UpdateCategory(name);
            return View(u);
        }
        [HttpPost]
        public IActionResult Update(Category category)
        {
          
            var p = categoryService.UpdateCategory(category);
            return RedirectToAction("Index", "Category");
        }
        public IActionResult Read()
        {
            
            var p = categoryService.ViewCategory();
            return View(p);
        }
        public IActionResult Read(string name)
        {
            var v = categoryService.ViewCategory(name);
            return View(v);
        }
        public IActionResult Index()
        {
            var li = categoryService.ViewCategory();
            return View(li);
        }
    }
}
