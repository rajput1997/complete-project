﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetProject.Respository.Contract;
using VishvajeetProject.Models;
using VishvajeetProject.Respository.Service;
using System.IO;

namespace VishvajeetProject.Controllers
{
   /* [Authorize]*/
    public class ProductController : Controller
    {
        private IProduct productService;
        private readonly IHostingEnvironment Environment;
        public ProductController(IProduct product, IHostingEnvironment environment) 
        {
            productService = product;
            Environment = environment;
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Product product)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "products", files[0].FileName);
                dbpath = "products/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            product.Image = dbpath;
            var p = productService.CreateProduct(product);
            return RedirectToAction("Create","Product");
        }
       
        public IActionResult Delete(int id)
        {
            var  d=productService.DeleteProduct(id);
            return RedirectToAction("Index","Product");
        }
        public IActionResult Update(int id)
        {
            var u = productService.UpdateP(id);
            return View(u);
        }
        [HttpPost]
        public IActionResult Update(Product product)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "products", files[0].FileName);
                dbpath = "products/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            product.Image = dbpath;
            var p = productService.UpdateProduct(product);
            return RedirectToAction("Index","Product") ;
        }
        [HttpGet]
        public IActionResult Read(Product product)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "products", files[0].FileName);
                dbpath = "products/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            product.Image = dbpath;
            var p = productService.UpdateProduct(product);
            return RedirectToAction("Index", "Product");
        }
        public IActionResult Read(int id)
        {
            var v = productService.ViewProduct(id);
            return View(v);
        }
        public IActionResult Index()
        {
            var v = productService.ViewProduct();
            return View(v);
        }
    }
}
