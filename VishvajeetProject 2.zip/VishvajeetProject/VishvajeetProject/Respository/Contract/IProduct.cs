﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetProject.Models;

namespace VishvajeetProject.Respository.Contract
{
    public interface IProduct
    {
        Product CreateProduct(Product product);
        bool DeleteProduct(int id);
        Product UpdateP(int id);
        bool UpdateProduct(Product product);
        List<Product> ViewProduct();
        Product ViewProduct(int id);
    }
}
