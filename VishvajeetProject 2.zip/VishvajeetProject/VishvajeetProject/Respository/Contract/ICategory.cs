﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetProject.Models;

namespace VishvajeetProject.Respository.Contract
{
     public interface ICategory
    {
        Category CreateCategory(Category category);
        bool DeleteCategory(int id);
        Category UpdateCategory(string name);
        bool UpdateCategory(Category category);
        List<Category> ViewCategory();
        Category ViewCategory(string name);
    }
}
