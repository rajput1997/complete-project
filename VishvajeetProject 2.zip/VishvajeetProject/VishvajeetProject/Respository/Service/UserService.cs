﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetProject.Models;
using VishvajeetProject.Utils.Enums;
using VishvajeetProject.Models.ViewModel;
using VishvajeetProject.Respository.Contract;
using System.Net.Mail;

namespace VishvajeetProject.Respository.Service
{
    public class UserService:IUser 
    {
        private AppDbContext dbContext;
        public UserService(AppDbContext _dbcontext)
        {
            dbContext = _dbcontext;
        }

        public AuthoEnum AuthenticateUser(SignIn model)
        {
            var user = dbContext.user.SingleOrDefault(e=>e.Email==model.Email && e.Password==model.Password);
            if (user == null)
            {
                return AuthoEnum.FAILED;
            }
            else if (user.IsVerified == true)
            {
                return AuthoEnum.SUCCESS;
            }
            else if (user.IsVerified == false)
            {
                return AuthoEnum.NOTVERIFIED;
            }
            else 
            {
                return AuthoEnum.NOTACTIVE;
            }
        }

        public SignUp Register(SignUp model)
        {
            if (dbContext.user.Any(e => e.Email == model.Email))
            {
                return null;
            }
            else 
            {
                var User = new Users()
                {
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Password = model.Password,
                    IsActive = true,
                    IsVerified = false
                };
                dbContext.user.Add(User);
                string otp = GenerateOTP();
                SendMail(model.Email,otp);
                var Vaccount = new VerifyAccount()
                {
                    UserEmail=model.Email,
                    OTP=otp,
                    SendTime=DateTime.Now
                };
                dbContext.verifyAccounts.Add(Vaccount);
                dbContext.SaveChanges();
                return model;
            }
        }

        private string GenerateOTP()
        {
            var chars= "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var rand = new Random();
            var list = Enumerable.Repeat(0, 8).Select(e=>chars[rand.Next(chars.Length)]);
            var r = string.Join("",list);
            return r;
        }

        private void SendMail(string email, string otp)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(email);
            mail.From = new MailAddress("demo3408@gmail.com");
            mail.Subject = "Verify your Account";
            string body = $"Your Otp is:{otp}</b> Thanks for choosing us";
            mail.Body = body;
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("vishvajeetchauhan2000@gmail.com", "V7379564797");//Enter senders user name and password
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }

        public bool UpdateProfile(string Email, string path)
        {
            var user = dbContext.user.SingleOrDefault(e=>e.Email==Email);
            user.Image = path;
            dbContext.user.Update(user);
            dbContext.SaveChanges();
            return true;
        }

        public VerifyAccountEnum VerifyAccount(string otp)
        {
            if (dbContext.verifyAccounts.Any(e => e.OTP == otp))
            {
                var ac = dbContext.verifyAccounts.SingleOrDefault(e => e.OTP == otp);
                var user = dbContext.user.SingleOrDefault(e => e.Email == ac.UserEmail);
                user.IsVerified = true;
                dbContext.verifyAccounts.Remove(ac);
                dbContext.user.Update(user);
                dbContext.SaveChanges();
                return VerifyAccountEnum.OTPVARIFIED;
            }
            else
            {
                return VerifyAccountEnum.INVALIDOTP;
            }
        }
    }
}
